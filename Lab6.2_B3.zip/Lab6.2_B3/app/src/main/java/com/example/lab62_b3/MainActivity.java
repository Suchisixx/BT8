package com.example.lab62_b3;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity {

    private EditText txtNumber;
    private Spinner spnUnits;
    private TextView[] lblResults;

    // Danh sách đơn vị đo chiều dài (Hải lý, Dặm, Km, Lý, Met, Yard, Foot, Inches)
    private String[] units = {
            "Hải lý", "Dặm", "Km", "Lý", "Met", "Yard", "Foot", "Inches"
    };

    // Ma trận tỉ lệ chiều dài (Dùng tỷ lệ từ tài liệu)
    private double[][] ratio = {
            // Hải lý
            {1.00000000, 1.15077945, 1.8520000, 20.2537183, 1852.0000, 2025.37183, 6076.11549, 72913.38583},
            // Dặm
            {0.86897624, 1.00000000, 1.6093440, 17.6000000, 1609.3440, 1760.00000, 5280.00000, 63360.00000},
            // Km
            {0.53995680, 0.62137119, 1.0000000, 10.9361330, 1000.0000, 1093.61330, 3280.83990, 39370.07874},
            // Lý
            {0.04937365, 0.05681818, 0.0914400, 1.0000000, 91.4400, 100.00000, 300.00000, 3600.00000},
            // Met
            {0.00053996, 0.00062137, 0.0010000, 0.0109361, 1.0000, 1.09361, 3.28084, 39.37008},
            // Yard
            {0.00049374, 0.00056818, 0.0009144, 0.0100000, 0.9144, 1.00000, 3.00000, 36.00000},
            // Foot
            {0.00016458, 0.00018939, 0.0003048, 0.0033333, 0.3048, 0.33333, 1.00000, 12.00000},
            // Inch
            {0.00001371, 0.00001578, 0.0000254, 0.0002778, 0.0254, 0.02778, 0.08333, 1.00000}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Kết nối các đối tượng View
        txtNumber = (EditText) findViewById(R.id.txtNumber);
        spnUnits = (Spinner) findViewById(R.id.spnUnit);

        // Khởi tạo mảng TextView kết quả
        lblResults = new TextView[] {
                (TextView) findViewById(R.id.lblNauticalMile),
                (TextView) findViewById(R.id.lblMile),
                (TextView) findViewById(R.id.lblKilometer),
                (TextView) findViewById(R.id.lblLy),
                (TextView) findViewById(R.id.lblMeter),
                (TextView) findViewById(R.id.lblYard),
                (TextView) findViewById(R.id.lblFoot),
                (TextView) findViewById(R.id.lblInch)
        };

        // 2. Đưa dữ liệu vào Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, units);

        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spnUnits.setAdapter(adapter);

        // 3. Thiết lập các hàm xử lý sự kiện

        spnUnits.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> argo, View arg1, int arg2, long arg3) {
                changeLengthUnit();
            }
            @Override
            public void onNothingSelected (AdapterView<?> arg0) { }
        });

        txtNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence argo, int arg1, int arg2, int arg3) {
                changeLengthUnit();
            }
            @Override
            public void beforeTextChanged (CharSequence argo, int arg1, int arg2, int arg3) { }
            @Override
            public void afterTextChanged(Editable arg) { }
        });

        changeLengthUnit();
    }

    // Hàm đổi đơn vị đo chiều dài
    private void changeLengthUnit() {
        int rowIdx = spnUnits.getSelectedItemPosition();
        if (rowIdx < 0) rowIdx = 0;

        String input = txtNumber.getText().toString();
        if (input.isEmpty())
            input = "0";

        double number = Double.valueOf(input);

        for (int i = 0; i < lblResults.length; i++) {
            double temp = number * ratio[rowIdx][i];

            // Dùng String.format để định dạng 4 chữ số thập phân cho đẹp, giống mẫu
            lblResults[i].setText(String.format("%,.4f", temp));
        }
    }
}