package com.example.lab71_b3;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private Button btnToast;
    private Button btnDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToast = (Button) findViewById(R.id.btnToast);
        btnDialog = (Button) findViewById(R.id.btnDialog);

        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomToast();
            }
        });

        btnDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomDialog();
            }
        });
    }

    // Hàm hiển thị Custom Toast (ĐÃ SỬA KÍCH THƯỚC VÀ CÁC LỖI ID)
    private void showCustomToast() {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast_layout,
                (ViewGroup) findViewById(R.id.custom_toast_container));

        // Tính toán kích thước
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;
        int halfScreenWidth = screenWidth / 2;

        // Đặt chiều rộng View gốc của Toast
        ViewGroup.LayoutParams params = layout.getLayoutParams();
        if (params == null) {
            params = new ViewGroup.LayoutParams(halfScreenWidth, ViewGroup.LayoutParams.WRAP_CONTENT);
        } else {
            params.width = halfScreenWidth;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        }
        layout.setLayoutParams(params);

        // Lỗi 67: text_toast
        TextView text = layout.findViewById(R.id.text_toast);
        text.setText("Custom Toast, made by Luc Vu");

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.show();
    }

    // Hàm hiển thị Custom Dialog
    private void showCustomDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        // Lỗi 80: custom_dialog_layout
        dialog.setContentView(R.layout.custom_dialog_layout);
        dialog.setTitle("Đăng nhập");

        // Lỗi 83, 84: dialog_button_bongy, dialog_button_thoat
        Button btnDongY = (Button) dialog.findViewById(R.id.dialog_button_dongy);
        Button btnThoat = (Button) dialog.findViewById(R.id.dialog_button_thoat);

        btnDongY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Bạn đã chọn ĐỒNG Ý", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        btnThoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                // finish();
            }
        });

        dialog.show();
    }
}