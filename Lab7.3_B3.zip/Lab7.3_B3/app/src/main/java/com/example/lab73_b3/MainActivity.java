package com.example.lab73_b3; // Đảm bảo package name khớp

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;

public class MainActivity extends Activity {

    // Khai báo Views
    private SeekBar seekBarR, seekBarG, seekBarB;
    private TextView lblR, lblG, lblB;
    private View colorViewRGB, colorViewCMY;

    // Khai báo giá trị màu hiện tại
    private int currentR = 0;
    private int currentG = 0;
    private int currentB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_chooser); // Đặt tên Layout

        // 1. Kết nối Views
        seekBarR = findViewById(R.id.seekBarR);
        seekBarG = findViewById(R.id.seekBarG);
        seekBarB = findViewById(R.id.seekBarB);

        lblR = findViewById(R.id.lblR);
        lblG = findViewById(R.id.lblG);
        lblB = findViewById(R.id.lblB);

        colorViewRGB = findViewById(R.id.colorViewRGB);
        colorViewCMY = findViewById(R.id.colorViewCMY);

        // 2. Khởi tạo giá trị và cập nhật lần đầu
        updateColor();

        // 3. Thiết lập Listener cho tất cả Seekbar
        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (seekBar.getId() == R.id.seekBarR) {
                    currentR = progress;
                    lblR.setText("R = " + progress);
                } else if (seekBar.getId() == R.id.seekBarG) {
                    currentG = progress;
                    lblG.setText("G = " + progress);
                } else if (seekBar.getId() == R.id.seekBarB) {
                    currentB = progress;
                    lblB.setText("B = " + progress);
                }
                updateColor();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Không cần làm gì
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Không cần làm gì
            }
        };

        seekBarR.setOnSeekBarChangeListener(listener);
        seekBarG.setOnSeekBarChangeListener(listener);
        seekBarB.setOnSeekBarChangeListener(listener);
    }

    /**
     * Hàm tính toán và cập nhật màu RGB và CMY
     */
    private void updateColor() {
        // A. TÍNH TOÁN MÀU RGB
        int colorRGB = Color.rgb(currentR, currentG, currentB);
        colorViewRGB.setBackgroundColor(colorRGB);

        // B. TÍNH TOÁN MÀU CMY (Màu bù)
        // Công thức: C = 255 - R; M = 255 - G; Y = 255 - B
        int colorC = 255 - currentR;
        int colorM = 255 - currentG;
        int colorY = 255 - currentB;

        int colorCMY = Color.rgb(colorC, colorM, colorY);
        colorViewCMY.setBackgroundColor(colorCMY);
    }
}