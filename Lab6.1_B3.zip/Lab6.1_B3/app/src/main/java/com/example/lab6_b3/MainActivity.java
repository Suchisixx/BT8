package com.example.lab6_b3;

import android.app.Activity; // Hoặc AppCompatActivity
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity { // Hãy đảm bảo lớp này khớp với Activity bạn đã khai báo trong AndroidManifest.xml

    // Khai báo các đối tượng View
    private EditText txtNumber;
    private Spinner spnUnits;
    private TextView[] lblResults;

    // Khai báo mảng đơn vị tiền tệ
    private String[] units = {
            "USD", "EUR", "GBP", "INR", "AUD",
            "CAD", "ZAR", "NZD", "JPY", "VND"
    };

    // Khai báo Ma trận tỉ giá (Dùng tỷ giá từ tài liệu)
    private double[][] ratio = {
            // Dòng/Cột:  USD         EUR         GBP         INR         AUD         CAD         ZAR         NZD         JPY         VND
            // USD
            {1.00000, 0.80518, 0.64070, 63.3318, 1.21828, 1.16236, 11.7129, 1.29310, 118.337, 21385.7},
            // EUR
            {1.24172, 1.00000, 0.79575, 78.6084, 1.51266, 1.44314, 14.5371, 1.60576, 146.927, 26561.8},
            // GBP
            {1.56044, 1.25667, 1.00000, 98.7848, 1.90091, 1.81355, 18.2683, 2.01791, 184.638, 33374.9},
            // INR
            {0.01580, 0.01272, 0.01012, 1.00000, 0.01924, 0.01836, 0.18493, 0.02043, 1.86910, 337.811},
            // AUD
            {0.82114, 0.66119, 0.52620, 52.0860, 1.00000, 0.95416, 9.61148, 1.06158, 97.1120, 17567.9},
            // CAD
            {0.86059, 0.69296, 0.55148, 54.5885, 1.04804, 1.00000, 10.0732, 1.11258, 101.777, 18401.7},
            // ZAR
            {0.08541, 0.06877, 0.05473, 5.40852, 0.10398, 0.09924, 1.00000, 0.11037, 10.0996, 1825.87},
            // NZD
            {0.77402, 0.62319, 0.49597, 49.0031, 0.94215, 0.89951, 9.06754, 1.00000, 91.5139, 16552.1},
            // JPY
            {0.00846, 0.00681, 0.00542, 0.53547, 0.01030, 0.00983, 0.09908, 0.01093, 1.00000, 180.837},
            // VND
            {0.00005, 0.00004, 0.00003, 0.00296, 0.00006, 0.00005, 0.00055, 0.00006, 0.00553, 1.00000}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Kết nối các đối tượng View
        txtNumber = (EditText) findViewById(R.id.txtNumber);
        spnUnits = (Spinner) findViewById(R.id.spnUnit);

        // Khởi tạo mảng TextView kết quả
        lblResults = new TextView[] {
                (TextView) findViewById(R.id.lblUsd),
                (TextView) findViewById(R.id.lblEur),
                (TextView) findViewById(R.id.lblGbp),
                (TextView) findViewById(R.id.lblInr),
                (TextView) findViewById(R.id.lblAud),
                (TextView) findViewById(R.id.lblCad),
                (TextView) findViewById(R.id.lblZar),
                (TextView) findViewById(R.id.lblNzd),
                (TextView) findViewById(R.id.lblJpy),
                (TextView) findViewById(R.id.lblVnd)
        };

        // 2. Đưa dữ liệu vào Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, units);

        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spnUnits.setAdapter(adapter);

        // 3. Thiết lập các hàm xử lý sự kiện

        // Sự kiện khi item trong Spinner thay đổi
        spnUnits.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> argo, View arg1, int arg2, long arg3) {
                changeMoneyUnit();
            }
            @Override
            public void onNothingSelected (AdapterView<?> arg0) { }
        });

        // Sự kiện khi nội dung ô nhập thay đổi
        txtNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence argo, int arg1, int arg2, int arg3) {
                changeMoneyUnit();
            }
            @Override
            public void beforeTextChanged (CharSequence argo, int arg1, int arg2, int arg3) { }
            @Override
            public void afterTextChanged(Editable arg) { }
        });

        // Gọi hàm đổi tiền lần đầu
        changeMoneyUnit();
    }

    // Hàm đổi đơn vị tiền tệ
    private void changeMoneyUnit() {
        // Lấy vị trí của đơn vị được chọn
        int rowIdx = spnUnits.getSelectedItemPosition();
        if (rowIdx < 0) rowIdx = 0;

        // Lấy giá trị từ ô nhập
        String input = txtNumber.getText().toString();
        if (input.isEmpty())
            input = "0";

        // Đổi giá trị nhập sang số thực
        double number = Double.valueOf(input);

        // Tính giá trị quy đổi ứng với từng loại tiên
        for (int i = 0; i < lblResults.length; i++) {
            double temp = number * ratio[rowIdx][i];

            // Hiển thị kết quả
            lblResults[i].setText(String.valueOf(temp));
        }
    }
}